# The live database moved

`wealth_advisor.db` in this folder is now a **stale, unused copy** — the app no longer reads or writes it.

**Reason:** this project directory lives inside OneDrive. OneDrive's sync agent holds an OS-level lock on a file while uploading/rescanning it after every write, which collides with SQLite's own locking and caused "database is locked" errors (including on ordinary actions like adding a new client). Confirmed independently of this app's code — even a plain `sqlite3.connect(...)` with zero app processes running still hit the lock, held by `OneDrive.Sync.Service`.

**The real, live database now lives at:**

```
%LOCALAPPDATA%\WealthAdvisorCopilot\wealth_advisor.db
```

(outside any OneDrive/cloud-synced folder). See [`backend/database.py`](../database.py) for the exact path resolution — run `python -c "from database import DB_PATH; print(DB_PATH)"` from `backend/` to print it directly.

**Point DB Browser for SQLite at that path**, not at the file in this folder.

The stale copy here is safe to delete once OneDrive releases its lock on it (it may still show as "busy" for a while after this note was written).
